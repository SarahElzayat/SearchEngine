package com.example.demo;

import org.json.JSONException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class test {
    public static void main(String[] args)throws JSONException {
        SpringApplication.run(test.class, args);
    }
}
